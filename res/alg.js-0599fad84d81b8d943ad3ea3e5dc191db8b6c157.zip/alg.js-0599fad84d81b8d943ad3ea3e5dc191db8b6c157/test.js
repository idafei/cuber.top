var alg = require("./alg");

console.log(alg.cube.fromString("R U [F, D] @5.34s // comment"))